DF OVERLAY – README (v1.3)

----------------------------------------
OVERVIEW
----------------------------------------
DF Overlay is an external tool for Dead Frontier that provides:

- Real-time EXP/hr tracking
- Average EXP/hr calculations
- Next Level ETA
- Goal Level ETA
- EXP history graph
- Hunger state detection (Nourished / Fine) using on-screen color sampling
- Scalable overlay with customizable appearance
- Online PID authorization
- Online version checking
- Patch notes loaded from the server

The tool reads visual data directly from your game window using pixel/OCR-style analysis.  
No game files or memory are modified at any time.

----------------------------------------
REQUIREMENTS
----------------------------------------
- Windows 10 or Windows 11
- Dead Frontier running in windowed mode
- Active internet connection (required for PID check)
- ZIP contents extracted (do NOT run from inside the ZIP)

INSTALLATION & SETUP ***

1. Extract the entire ZIP file to a folder.
2. Run "DF_Overlay.exe".
3. Enter your DF PID when prompted.
4. If your PID is authorized, the overlay will start automatically.


CONTROLS ***

F1  – Open settings menu  
ESC – Close the overlay  

To move the overlay, click and drag any text area.
You may enable "Lock Position" in the settings to prevent movement.


SETTINGS ***

GENERAL TAB:
- Lock overlay position
- Toggle EXP/hr, AVG/hr, ETAs, update time, graph
- EXP mode (RAW, AVG3, AVG5)
- Set goal level for ETA calculations

APPEARANCE TAB:
- Text color picker
- Font selection
- Scale adjustment
- Hunger icon size

INFO TAB:
- Open Debug Window
- View Patch Notes (fetched from website)


HUNGER DETECTION ***

The overlay detects the hunger icon using template matching and pixel color sampling.

Two hunger states are recognized:
- NOURISHED (green)
- FINE (yellow)

When the state is FINE, the hunger icon blinks as a reminder.


EXP TRACKING (OCR / SCREEN READING) ***

The overlay reads EXP and level information visually from your Dead Frontier profile using HTML rendering + OCR-style text extraction (no packet reading, no memory access).

The tool:
- Reads your displayed EXP value
- Calculates EXP gain over time
- Computes EXP/hr, averages, and ETAs
- Displays a smooth rolling graph of recent performance

This method is **fully external** and **non-intrusive**.


ONLINE AUTHORIZATION ***

When the application starts, your PID is checked against a remote
authorization list hosted on gaslightgod.com.

If your PID is not authorized or cannot be validated, the tool will close.


VERSION CHECKING ***

At launch, the tool checks the latest version number online.
If a newer version is available, you will be notified with a link to download it.


TROUBLESHOOTING ***

• Overlay won't start:
    - Ensure your PID is authorized.
    - Make sure your game window title is exactly “Dead Frontier”.
    - Verify your internet connection.

• Hunger detection isn’t working:
    - Ensure the game window is visible and not minimized.
    - Minor window size changes can affect template matching.

• EXP values look incorrect:
    - Make sure your profile loads properly when requested.
    - Network delays may cause temporary inconsistencies.

CREDITS ***

DF Overlay by GaslightGod  
Version 1.3  
https://gaslightgod.com
