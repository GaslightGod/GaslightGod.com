===========================================
           DF OVERLAY - VERSION 1.71
===========================================

Thank you for using the DF Overlay!

This tool tracks your EXP/hr, average rates, 
time until next level, time until your goal
level, and hunger status all in real time.

It is completely external and never interacts
with the game client. It only reads what is
already visible on your screen.

-------------------------------------------
HOW TO USE
-------------------------------------------

1. Run DF_Overlay.exe
2. Enter your DF PID when asked
3. The overlay will appear on your screen
4. Press F5 to open the Settings menu
5. Press ESC to close the overlay

You can drag the overlay anywhere unless
"Lock Position" is enabled in Settings.

-------------------------------------------
AUTO UPDATER
-------------------------------------------

If a new version is available, you will be
asked whether you want to update when the
program launches.

**The manual update button can be found in the settings menu**

Click "Update Now" to download and install
the latest version automatically.

The updater is included as:
    updater.exe

DO NOT DELETE THIS FILE

-------------------------------------------
FEATURES
-------------------------------------------

• Real-time EXP/hr tracking
• 3 smoothing modes: RAW, AVG3, AVG5
• Time to next level (ETA)
• Time to goal level (ETA)
• Clock display
• Draggable overlay
• Custom fonts, colors, and scaling
• Hunger detection with visual alert
• Built-in Update Checker
• Debug Window for troubleshooting
• PID saving option

-------------------------------------------
SUPPORT
-------------------------------------------

Website:
https://gaslightgod.com

Discord:
TheGaslightGod

Special thanks to Karmash for testing.

-------------------------------------------
NOTES
-------------------------------------------

This tool does NOT modify the game.
Nothing is injected or altered.

-------------------------------------------

Thanks for using the DF Overlay!
